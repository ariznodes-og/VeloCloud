// @ts-check

/**
 * Copilot SDK Session Runner
 *
 * Runs a single Copilot agentic session using the @github/copilot-sdk.
 * Serializes all SDK session events to a JSONL file so that
 * unified_session.cjs can collect them for the unified session step summary.
 *
 * Retains native non-ephemeral events and selected ephemeral conversation,
 * accounting, failure and workflow observations. Tool enrichment and canonical
 * conversion are performed by copilot_session.cjs, not the native capture.
 * Assistant turn events also control the idle watchdog.
 *
 * The JSONL file is written to:
 *   /tmp/gh-aw/sandbox/agent/logs/copilot-session-state/{sessionId}/events.jsonl
 * which mirrors the path that copy_copilot_session_state.sh produces and that
 * unified_session.cjs reads.
 *
 * Consumed directly by copilot_sdk_driver.cjs (the built-in gh-aw driver) and
 * available to any custom driver that wants the same session lifecycle and JSONL
 * telemetry without duplicating the implementation.
 */

"use strict";

const { getErrorMessage } = require("./error_helpers.cjs");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { isDeepStrictEqual } = require("node:util");
const { buildCopilotSDKPermissionHandler, getEnvPositiveIntOrDefault, parseMaxToolDenialsLimit, MAX_TOOL_DENIALS_DEFAULT } = require("./copilot_sdk_permissions.cjs");
const { buildCopilotSDKSessionToolConfig } = require("./copilot_sdk_tool_config.cjs");
const { buildCopilotSDKToolCallBudget } = require("./copilot_sdk_tool_budget.cjs");
const { resolveModelWithFallback } = require("./model_fallback.cjs");
const { COPILOT_WORKFLOW_EVENT_TYPES } = require("./copilot_workflow_events.cjs");
const { copilotSessionContext } = require("./copilot_session.cjs");
const { loadCopilotSDKCustomAgents } = require("./extract_inline_sub_agents.cjs");
const { qualifyModelForMultiProvider, parseMultiProviderJson } = require("./copilot_sdk_multi_provider.cjs");

const CAPTURED_EPHEMERAL_EVENTS = new Set([...COPILOT_WORKFLOW_EVENT_TYPES, "assistant.usage", "assistant.message_delta", "assistant.reasoning_delta", "model.call_failure", "model.call_final_result"]);

// Default timeout for a single sendAndWait call: 10 minutes.
// This is intentionally generous — the headless Copilot CLI has its own internal
// timeouts for individual tool calls and model inference.
// Override via the COPILOT_SDK_SEND_TIMEOUT_MS environment variable.
const SDK_SEND_TIMEOUT_MS_DEFAULT = 10 * 60 * 1000;

// Pattern matching the SDK idle-timeout error emitted when sendAndWait reaches its
// deadline waiting for the session.idle event.  This matches the message format
// "Timeout after <N>ms waiting for session.idle" produced by the Copilot SDK.
// Keep in sync with SDK_SESSION_IDLE_TIMEOUT_PATTERN in copilot_harness.cjs.
const SDK_IDLE_TIMEOUT_PATTERN = /Timeout after \d+ms waiting for session\.idle/;

// Bounded interval, in milliseconds, that the driver waits after the tool-denial
// guard (guard.tool_denials_exceeded) fires before forcing sendAndWait to settle,
// even if session.disconnect() or the in-flight SDK request never resolves on its
// own. Without this, a stalled disconnect/sendAndWait leaves the process hanging
// until the surrounding job's own timeout kicks in (observed up to ~49 minutes).
// Override via the GH_AW_DENIAL_GUARD_TIMEOUT_MS environment variable.
const DENIAL_GUARD_FORCE_EXIT_MS_DEFAULT = 15 * 1000;

// Default idle period for the post-completion watchdog: 30 seconds.
// When the agent has produced output and all tracked tool calls have completed,
// the driver arms a watchdog timer.  If no new SDK events arrive within this
// window, the driver force-disconnects the session and treats it as a successful
// completion — covering the SDK driver bug where sendAndWait never resolves after
// the final tool result is returned.
// 30 s is chosen to be well under typical step timeouts (≥ 5 min) while still
// being long enough to avoid false-positives during legitimate LLM inference gaps
// (the session.on handler disarms the watchdog on every assistant.turn_start event,
// so the timer only fires when the session is truly quiescent: output collected,
// no tool calls in flight, and no active inference turn).
// Override via the GH_AW_SDK_IDLE_MS environment variable.
const SDK_POST_COMPLETION_IDLE_MS_DEFAULT = 30 * 1000;

/**
 * Extract the prompt text from a resolved args array.
 * Looks for the first occurrence of "-p <value>" or "--prompt <value>".
 *
 * @param {string[]} args - Resolved CLI arguments.
 * @returns {string | null} The prompt text, or null if not found.
 */
function extractPromptFromArgs(args) {
  for (let i = 0; i < args.length - 1; i++) {
    if (args[i] === "-p" || args[i] === "--prompt") {
      return args[i + 1];
    }
  }
  return null;
}

/** @param {string | undefined} serverArgs @param {(message: string) => void} [logger] @returns {boolean} */
function isCopilotSDKBareMode(serverArgs, logger = message => process.stderr.write(`[copilot-sdk] ${message}\n`)) {
  try {
    const args = JSON.parse(serverArgs || "[]");
    if (!Array.isArray(args) || args.some(arg => typeof arg !== "string")) throw new Error("expected a string array");
    return args.includes("--no-custom-instructions");
  } catch (error) {
    logger(`warning: Invalid GH_AW_COPILOT_SDK_SERVER_ARGS: ${getErrorMessage(error)}; using sidecar default args`);
    return false;
  }
}

/** @returns {string} */
function resolveCopilotSDKWorkingDirectory() {
  return path.resolve(process.env.GITHUB_WORKSPACE || process.cwd(), process.env.GH_AW_ENGINE_CWD || ".");
}

/**
 * Run a Copilot agentic session using the @github/copilot-sdk.
 *
 * Connects to the already-running headless Copilot CLI server at sdkUri, creates
 * a session, sends the prompt, waits for the session to go idle, and returns a
 * result shape that mirrors what runProcess() returns so that callers can treat
 * both modes uniformly.
 *
 * All SDK events are serialised to a JSONL file under the session state directory
 * so that unified_session.cjs can collect them for the step summary.
 *
 * @param {{
 *   sdkUri: string,
 *   prompt: string,
 *   logger: (msg: string) => void,
 *   attempt?: number,
 *   model?: string,
 *   reasoningEffort?: string,
 *   connectionToken?: string,
 *   providers?: import("@github/copilot-sdk").NamedProviderConfig[],
 *   models?: import("@github/copilot-sdk").ProviderModelConfig[],
 *   maxToolDenials?: number | string,
 *   permissionConfig?: {
 *     allowAllTools?: boolean,
 *     allowedTools?: string[],
 *   },
 *   toolConfig?: import("./copilot_sdk_tool_config.cjs").CopilotSDKToolConfig,
 *   webFetchOptions?: {fetchImpl?: typeof fetch, timeoutMs?: number, maxRedirects?: number},
 *   coreLogger?: import("./copilot_sdk_permissions.cjs").CopilotSDKCoreLogger,
 *   sdkModule?: {
 *     CopilotClient: typeof import("@github/copilot-sdk").CopilotClient,
 *     RuntimeConnection: typeof import("@github/copilot-sdk").RuntimeConnection,
 *     approveAll: typeof import("@github/copilot-sdk").approveAll,
 *     ToolSet?: typeof import("@github/copilot-sdk").ToolSet,
 *     BuiltInTools?: typeof import("@github/copilot-sdk").BuiltInTools,
 *     defineTool?: typeof import("@github/copilot-sdk").defineTool,
 *   },
 *   sessionStateBaseDir?: string,
 *   workingDirectory?: string,
 *   agentsBaseDir?: string,
 *   bare?: boolean,
 * }} options
 * @returns {Promise<{exitCode: number, output: string, hasOutput: boolean, durationMs: number}>}
 */
async function runWithCopilotSDK({
  sdkUri,
  prompt,
  logger,
  attempt = 0,
  model,
  reasoningEffort,
  connectionToken,
  providers,
  models: providerModels,
  maxToolDenials,
  permissionConfig,
  toolConfig,
  webFetchOptions,
  coreLogger,
  sdkModule,
  sessionStateBaseDir,
  workingDirectory = resolveCopilotSDKWorkingDirectory(),
  agentsBaseDir = path.join(os.tmpdir(), "gh-aw"),
  bare = isCopilotSDKBareMode(process.env.GH_AW_COPILOT_SDK_SERVER_ARGS, logger),
}) {
  // Lazy-require to avoid loading the SDK when it is not needed.
  // The SDK is large and has side-effects on import (worker threads, etc.).
  const sdk = sdkModule ?? require("@github/copilot-sdk");
  const { CopilotClient, RuntimeConnection, approveAll } = sdk;

  const startTime = Date.now();
  let output = "";
  let hasOutput = false;

  const log = msg => logger(`[sdk-driver] ${msg}`);
  log(`attempt ${attempt + 1}: connecting to Copilot SDK at ${sdkUri}`);
  let maxToolDenialsLimit = MAX_TOOL_DENIALS_DEFAULT;
  if (maxToolDenials === undefined) {
    maxToolDenialsLimit = getEnvPositiveIntOrDefault("GH_AW_MAX_TOOL_DENIALS", MAX_TOOL_DENIALS_DEFAULT);
  } else {
    maxToolDenialsLimit = parseMaxToolDenialsLimit(maxToolDenials);
  }
  log(`max-tool-denials threshold: ${maxToolDenialsLimit}`);

  // Session state directory — mirrors the source path used by unified_session.cjs.
  // /tmp/gh-aw/sandbox/agent/logs/copilot-session-state/{sessionId}/events.jsonl
  // GH_AW_SESSION_STATE_BASE_DIR may be set in tests to redirect writes to an isolated directory.
  const defaultSessionStateBase = path.join(os.tmpdir(), "gh-aw", "sandbox", "agent", "logs", "copilot-session-state");
  const sessionStateBase = sessionStateBaseDir ?? process.env.GH_AW_SESSION_STATE_BASE_DIR ?? defaultSessionStateBase;

  /** @type {ReadonlyArray<NonNullable<import("@github/copilot-sdk").CopilotClientOptions["logLevel"]>>} */
  const VALID_LOG_LEVELS = ["none", "error", "warning", "info", "debug", "all"];
  const rawLogLevel = process.env.COPILOT_SDK_LOG_LEVEL ?? "";
  /**
   * @param {string} value
   * @returns {value is NonNullable<import("@github/copilot-sdk").CopilotClientOptions["logLevel"]>}
   */
  const isValidLogLevel = value => {
    /** @type {readonly string[]} */
    const validLogLevels = VALID_LOG_LEVELS;
    return validLogLevels.includes(value);
  };
  /** @type {import("@github/copilot-sdk").CopilotClientOptions["logLevel"]} */
  const logLevel = isValidLogLevel(rawLogLevel) ? rawLogLevel : "warning";

  const connection = RuntimeConnection.forUri(sdkUri, {
    connectionToken,
  });
  const client = new CopilotClient({
    connection,
    workingDirectory,
    logLevel,
  });
  /** @type {any} */
  let session = null;
  /** @type {fs.WriteStream | null} */
  let eventsStream = null;
  let clientStarted = false;
  let toolDenialCount = 0;
  let assistantTurnCount = 0;
  /** @type {any} */
  let catastrophicToolDenialsError = null;
  let catastrophicToolDenialsTriggered = false;
  /**
   * Rejects `denialGuardPromise` once the tool-denial threshold is exceeded and the
   * bounded force-exit interval elapses. Declared here so `recordToolDenial` (defined
   * below) can arm the forced settlement independent of whether `session.disconnect()`
   * or the in-flight `sendAndWait()` call ever resolves on their own.
   * @type {((reason: any) => void) | null}
   */
  let denialGuardReject = null;
  /** @type {ReturnType<typeof setTimeout> | null} */
  let denialGuardTimer = null;
  /**
   * Settles (rejects) only when the tool-denial guard forces an early exit after
   * `DENIAL_GUARD_FORCE_EXIT_MS_DEFAULT` (or `GH_AW_DENIAL_GUARD_TIMEOUT_MS`) elapses
   * following `guard.tool_denials_exceeded`. Raced against `session.sendAndWait()` so
   * the driver settles with a nonzero exit within a bounded interval even when
   * disconnect or the in-flight SDK request stalls.
   * @type {Promise<never>}
   */
  const denialGuardPromise = new Promise((_resolve, reject) => {
    denialGuardReject = reject;
  });
  // Prevent an unhandled-rejection warning when the guard never fires (the common
  // case): the promise is still raced below, but Node considers a promise
  // "handled" only once a rejection handler has actually been attached, and the
  // race only attaches one when sendAndWait settles first. The rejection reason
  // is already logged and handled via the Promise.race() result below, so this
  // is an intentional no-op (safe to ignore).
  denialGuardPromise.catch(() => {});
  /**
   * Scoped toolCallIds for tracking in-flight tool calls when the idle-timeout fires.
   * Declared at function scope so the catch block can check pendingToolCalls.size.
   * @type {Set<string>}
   */
  const pendingToolCalls = new Set();

  // Post-completion idle watchdog.
  // When the agent has produced output and all tracked tool calls have completed,
  // this timer is armed.  If no new SDK events arrive within GH_AW_SDK_IDLE_MS
  // (default 5 minutes), the watchdog force-disconnects the session and the catch
  // block treats the result as a successful completion.  This bounds the damage
  // from the SDK driver bug where sendAndWait never resolves after the final
  // tool result is returned.
  const postCompletionIdleMs = getEnvPositiveIntOrDefault("GH_AW_SDK_IDLE_MS", SDK_POST_COMPLETION_IDLE_MS_DEFAULT);
  let postCompletionWatchdogTriggered = false;
  /** @type {ReturnType<typeof setTimeout> | null} */
  let postCompletionWatchdog = null;
  // Tracks whether the LLM is mid-inference (between assistant.turn_start and
  // assistant.turn_end).  The watchdog must not fire during this window because
  // pendingToolCalls may legitimately be empty before the model dispatches its
  // first tool call of the new turn.
  let inAssistantTurn = false;
  const activeAssistantTurns = new Set();

  /**
   * Best-effort write of a driver-level event to events.jsonl and stderr.
   * @param {string} type
   * @param {any} data
   */
  function writeDriverEvent(type, data) {
    const entry = { type, timestamp: new Date().toISOString(), data };
    const jsonl = JSON.stringify(entry) + "\n";
    if (eventsStream) {
      eventsStream.write(jsonl);
    }
    process.stderr.write(jsonl);
  }

  /**
   * @param {string} reason
   */
  function recordToolDenial(reason) {
    toolDenialCount += 1;
    log(`tool denial ${toolDenialCount}/${maxToolDenialsLimit}: ${reason}`);
    if (catastrophicToolDenialsTriggered || toolDenialCount < maxToolDenialsLimit) {
      return;
    }
    catastrophicToolDenialsTriggered = true;
    catastrophicToolDenialsError = new Error(`max tool denials threshold reached (${toolDenialCount}/${maxToolDenialsLimit})`);
    writeDriverEvent("guard.tool_denials_exceeded", {
      denialCount: toolDenialCount,
      threshold: maxToolDenialsLimit,
      reason,
    });
    log(`${catastrophicToolDenialsError.message}; stopping SDK session early`);
    if (session) {
      void session.disconnect().catch(() => {
        // best-effort early stop
      });
    }
    // Force sendAndWait to settle within a bounded interval even if disconnect()
    // or the in-flight SDK request never resolves on its own (observed hosted
    // failure: the process remained stalled for ~49 minutes after this guard
    // fired, until the surrounding job's own timeout cancelled it).
    const denialGuardTimeoutMs = getEnvPositiveIntOrDefault("GH_AW_DENIAL_GUARD_TIMEOUT_MS", DENIAL_GUARD_FORCE_EXIT_MS_DEFAULT);
    denialGuardTimer = setTimeout(() => {
      if (denialGuardReject) {
        log(`warning: denial guard force-exit fired after ${denialGuardTimeoutMs}ms — sendAndWait did not settle on its own`);
        denialGuardReject(catastrophicToolDenialsError);
      }
    }, denialGuardTimeoutMs);
  }

  try {
    await client.start();
    clientStarted = true;
    log("client started");

    /**
     * Build the session on-permission handler from configuration input.
     * @type {import("@github/copilot-sdk").PermissionHandler}
     */
    const onPermissionRequest = buildCopilotSDKPermissionHandler(permissionConfig, approveAll, {
      coreLogger,
      logger: log,
      onDenied: requestSummary => recordToolDenial(`permission denied: ${requestSummary}`),
      workspaceRoot: workingDirectory,
    });
    const toolCallBudget = buildCopilotSDKToolCallBudget(toolConfig?.maxToolCalls, event => {
      writeDriverEvent(event.exhausted ? "guard.tool_call_budget_exceeded" : "guard.tool_call_budget_debit", event);
    });

    // Build session config using the multi-provider surface.
    /** @type {any} */
    const sdkReasoningEffort = reasoningEffort;
    const reflectedConfig = parseMultiProviderJson(process.env.GH_AW_COPILOT_SDK_MULTI_PROVIDER_JSON);
    providers ??= reflectedConfig?.providers;
    providerModels ??= reflectedConfig?.models;
    const envModel = process.env.GH_AW_MODEL_ROUTING === "1" ? process.env.COPILOT_MODEL : resolveModelWithFallback(process.env, "COPILOT_MODEL");
    const requestedModel = model || envModel || reflectedConfig?.model || undefined;
    const providerConfig = providers && providerModels ? { providers, models: providerModels } : null;
    const sessionModel = providerConfig ? qualifyModelForMultiProvider(requestedModel, providerConfig) : requestedModel;
    if (providerConfig && !sessionModel) throw new Error(`Cannot qualify session model "${requestedModel || "(none)"}" against the configured provider models`);
    const unavailableModels = [];
    const customAgents = loadCopilotSDKCustomAgents(workingDirectory, agentsBaseDir, log).map(agent => {
      const requested = agent.model;
      const alias = !requested || ["small", "medium", "large"].includes(requested.toLowerCase());
      const qualified = alias ? sessionModel : providerConfig ? qualifyModelForMultiProvider(requested, providerConfig) : requested;
      if (!alias && !qualified) {
        log(`warning: custom agent "${agent.name}" model "${requested}" is not in the configured provider models; using session model "${sessionModel || "(none)"}"`);
        unavailableModels.push({ agentName: agent.name, declaredModel: requested, model: sessionModel || undefined });
      }
      return { ...agent, model: qualified || sessionModel || undefined };
    });
    /** @type {import("@github/copilot-sdk").SessionConfig} */
    const sessionConfig = {
      model: sessionModel || undefined,
      ...(sdkReasoningEffort ? { reasoningEffort: sdkReasoningEffort } : {}),
      providers,
      models: providerModels,
      workingDirectory,
      skipCustomInstructions: bare,
      customAgents,
      onPermissionRequest,
      ...(toolCallBudget ? { hooks: { onPreToolUse: toolCallBudget.onPreToolUse } } : {}),
      ...buildCopilotSDKSessionToolConfig(toolConfig, sdk, webFetchOptions),
    };
    log(`creating session with model="${sessionConfig.model || "(none)"}" providers=${providers?.length ?? 0} models=${providerModels?.length ?? 0}`);
    session = await client.createSession(sessionConfig);
    log(`session created: sessionId=${session.sessionId}`);

    // Prepare JSONL output file for this session.
    const sessionDir = path.join(sessionStateBase, session.sessionId);
    fs.mkdirSync(sessionDir, { recursive: true });
    const eventsPath = path.join(sessionDir, "events.jsonl");
    eventsStream = fs.createWriteStream(eventsPath, { flags: "a" });
    for (const unavailable of unavailableModels) writeDriverEvent("subagent.model_unavailable", unavailable);
    // Snapshot to a non-null local for closure-safe writes (JSDoc nullability narrowing).
    const stream = eventsStream;
    const assistantEvents = [];
    log(`serialising SDK events to ${eventsPath}`);

    /**
     * Write one JSONL entry to the events file and stderr.
     * Retains the native envelope, including an absent timestamp.
     *
     * @param {string} type
     * @param {any} data
     * @param {string | undefined} [timestamp]
     * @param {Record<string, any>} [native]
     */
    function writeEvent(type, data, timestamp, native = {}) {
      const entry = { ...native, type, ...(timestamp !== undefined ? { timestamp } : {}), data };
      const jsonl = JSON.stringify(entry) + "\n";
      stream.write(jsonl);
      process.stderr.write(jsonl);
    }

    session.on(event => {
      if (event.ephemeral && !CAPTURED_EPHEMERAL_EVENTS.has(event.type)) return;
      const data = { ...event.data };
      if (event.type.startsWith("subagent.") && data.agentName && data.agentDisplayName) data.agentDisplayName = data.agentName;
      if (data.agentMetrics) {
        data.agentMetrics = Object.fromEntries(Object.entries(data.agentMetrics).map(([id, metric]) => [id, metric.agentName ? { ...metric, agentDisplayName: metric.agentName } : metric]));
      }
      const context = copilotSessionContext(event);
      const scope = JSON.stringify([context.agentId, context.parentToolUseId]);
      const toolKey = JSON.stringify([scope, data.toolCallId]);

      switch (event.type) {
        case "tool.execution_start": {
          if (data.toolCallId !== undefined) pendingToolCalls.add(toolKey);
          break;
        }

        case "tool.execution_complete": {
          if (data.toolCallId !== undefined) pendingToolCalls.delete(toolKey);
          break;
        }

        case "assistant.message": {
          assistantEvents.push(event);
          const content = data.content;
          if (typeof content === "string" && content && context.agentId === undefined && !context.parentToolUseId) {
            hasOutput = true;
            output += content;
            assistantTurnCount++;
          }
          break;
        }

        case "assistant.turn_start":
          // LLM inference started for a new turn. Disarm the watchdog — the model
          // may not have dispatched any tool calls yet, so pendingToolCalls can be
          // empty while real work is still in progress.
          activeAssistantTurns.add(scope);
          inAssistantTurn = true;
          if (postCompletionWatchdog) {
            clearTimeout(postCompletionWatchdog);
            postCompletionWatchdog = null;
          }
          break;

        case "assistant.turn_end":
          // LLM inference finished. Allow the watchdog to re-arm on the next event
          // that satisfies the completion conditions.
          activeAssistantTurns.delete(scope);
          inAssistantTurn = activeAssistantTurns.size > 0;
          break;
      }
      writeEvent(event.type, data, event.timestamp, event);

      // After processing each event, update the post-completion watchdog:
      // - Arm (or rearm) the watchdog when the session looks complete: output
      //   collected, no tool calls still in flight, and not mid-LLM-inference.
      // - Disarm the watchdog whenever the session is still mid-turn (a new
      //   tool call was just started, LLM inference is in progress, or no output yet).
      // The watchdog fires only if sendAndWait never resolves on its own after
      // the final tool result is returned — the common SDK post-completion hang.
      if (hasOutput && pendingToolCalls.size === 0 && !inAssistantTurn) {
        if (postCompletionWatchdog) clearTimeout(postCompletionWatchdog);
        postCompletionWatchdog = setTimeout(() => {
          postCompletionWatchdog = null;
          // Re-check conditions at fire time: a new tool call could have started
          // or a new turn could have begun between arming the watchdog and the
          // timer firing (race condition guard).
          if (!hasOutput || pendingToolCalls.size !== 0 || inAssistantTurn || !session) return;
          log(`warning: post-completion idle watchdog fired after ${postCompletionIdleMs}ms — force-disconnecting session`);
          postCompletionWatchdogTriggered = true;
          void session.disconnect().catch(err => {
            log(`warning: post-completion watchdog disconnect failed: ${getErrorMessage(err)}`);
          });
        }, postCompletionIdleMs);
      } else {
        if (postCompletionWatchdog) {
          clearTimeout(postCompletionWatchdog);
          postCompletionWatchdog = null;
        }
      }
    });

    log("sending prompt...");
    const sendTimeoutMs = getEnvPositiveIntOrDefault("COPILOT_SDK_SEND_TIMEOUT_MS", SDK_SEND_TIMEOUT_MS_DEFAULT);
    // Race against denialGuardPromise so that if the tool-denial guard fires and
    // session.disconnect()/sendAndWait then stall, the driver still settles with a
    // nonzero exit within a bounded interval instead of hanging until the job's own
    // timeout intervenes. denialGuardPromise never settles unless the guard fires.
    const result = await Promise.race([session.sendAndWait({ prompt }, sendTimeoutMs), denialGuardPromise]);

    if (catastrophicToolDenialsError) {
      throw catastrophicToolDenialsError;
    }

    // sendAndWait returns the last assistant.message event; capture its content
    // as a fallback in case the on() handler missed it.
    if (result && !hasOutput) {
      if (!assistantEvents.some(event => isDeepStrictEqual(event, result))) writeEvent("assistant.message", result.data, result.timestamp, result);
      const context = copilotSessionContext(result);
      const content = result.data?.content;
      if (typeof content === "string" && content && context.agentId === undefined && !context.parentToolUseId) {
        output = content;
        hasOutput = true;
        assistantTurnCount++;
      }
    }

    const durationMs = Date.now() - startTime;
    log(`session completed: hasOutput=${hasOutput} assistantTurns=${assistantTurnCount} durationMs=${durationMs}`);

    return { exitCode: 0, output, hasOutput, durationMs };
  } catch (err) {
    const durationMs = Date.now() - startTime;
    const failure = catastrophicToolDenialsError ?? (err instanceof Error ? err : new Error(String(err)));
    log(`error: ${failure.message}`);

    // When the post-completion idle watchdog force-disconnected the session, the
    // agent's work is done — the SDK simply failed to resolve sendAndWait after
    // the final tool result was returned.  Treat it as a successful completion.
    if (postCompletionWatchdogTriggered && !catastrophicToolDenialsError && hasOutput && pendingToolCalls.size === 0) {
      log(`warning: post-completion watchdog triggered disconnect — treating as completed`);
      log(`session completed: hasOutput=${hasOutput} assistantTurns=${assistantTurnCount} durationMs=${durationMs}`);
      return { exitCode: 0, output, hasOutput, durationMs };
    }

    // When sendAndWait times out waiting for session.idle but the agent produced
    // output and all tracked tool calls have already completed, the session work is
    // done — the SDK simply failed to emit the idle signal.  Treat it as a successful
    // run so the harness does not classify it as a failure or waste retry attempts.
    const isIdleTimeout = !catastrophicToolDenialsError && SDK_IDLE_TIMEOUT_PATTERN.test(failure.message);
    if (isIdleTimeout && hasOutput && pendingToolCalls.size === 0) {
      log(`warning: SDK idle-timeout with collected output and no pending tool calls — treating as completed`);
      log(`session completed: hasOutput=${hasOutput} assistantTurns=${assistantTurnCount} durationMs=${durationMs}`);
      return { exitCode: 0, output, hasOutput, durationMs };
    }

    writeDriverEvent("session.error", { errorType: "sdk_driver", message: failure.message, ...("code" in failure ? { code: failure.code } : {}) });

    // Preserve any output collected before the error so the harness can use it
    // for retry decisions and diagnostics.
    return {
      exitCode: 1,
      output: hasOutput ? output : failure.message,
      hasOutput,
      durationMs,
    };
  } finally {
    if (denialGuardTimer) {
      clearTimeout(denialGuardTimer);
      denialGuardTimer = null;
    }
    // Clear the post-completion watchdog if it has not already fired.
    if (postCompletionWatchdog) {
      clearTimeout(postCompletionWatchdog);
      postCompletionWatchdog = null;
    }
    // Snapshot for null-safe cleanup in this scope.
    const stream = eventsStream;
    if (stream) {
      await new Promise(resolve => stream.end(resolve));
    }
    // Timeout budget for each cleanup operation.  Prevents the driver from
    // hanging indefinitely when the server is unresponsive after sendAndWait
    // times out or the watchdog force-disconnects the session.
    // The helper resolves normally on success and also on timeout (signalling
    // timeout via the returned boolean) so the caller can log a warning.
    const CLEANUP_TIMEOUT_MS = 5_000;
    /**
     * Race a cleanup promise against a fixed deadline.
     * Resolves to true when the promise settled in time, false on timeout.
     * @param {Promise<unknown>} p
     * @returns {Promise<boolean>}
     */
    const withCleanupTimeout = p => {
      /** @type {any} */
      let timeoutId = null;
      const deadline = new Promise(resolve => {
        timeoutId = setTimeout(() => {
          timeoutId = null;
          resolve(false);
        }, CLEANUP_TIMEOUT_MS);
        if (typeof timeoutId?.unref === "function") timeoutId.unref();
      });
      return Promise.race([
        p.then(
          () => true,
          () => true
        ),
        deadline,
      ]).then(settled => {
        if (timeoutId) clearTimeout(timeoutId);
        if (!settled) {
          log(`warning: cleanup operation timed out after ${CLEANUP_TIMEOUT_MS}ms`);
        }
        return settled;
      });
    };
    if (session) {
      try {
        await withCleanupTimeout(session.disconnect());
      } catch {
        // best-effort cleanup
      }
    }
    if (clientStarted) {
      try {
        await withCleanupTimeout(client.stop());
      } catch {
        // best-effort cleanup
      }
    }
  }
}

module.exports = { SDK_SEND_TIMEOUT_MS_DEFAULT, SDK_POST_COMPLETION_IDLE_MS_DEFAULT, SDK_IDLE_TIMEOUT_PATTERN, extractPromptFromArgs, runWithCopilotSDK, isCopilotSDKBareMode, resolveCopilotSDKWorkingDirectory };
