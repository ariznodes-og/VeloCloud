// @ts-check
/// <reference types="@actions/github-script" />

const { getErrorMessage } = require("./error_helpers.cjs");
const { fetchAndLogRateLimit } = require("./github_rate_limit_logger.cjs");

/**
 * Rate limit check for per-user per-workflow triggers
 * Prevents users from triggering workflows too frequently
 */

// Keep in sync with pkg/workflow/role_checks.go and the user-rate-limit.events schema enum.
const PROGRAMMATIC_EVENTS = ["discussion", "discussion_comment", "issue_comment", "issues", "pull_request", "pull_request_review", "pull_request_review_comment", "repository_dispatch", "workflow_dispatch"];

async function main() {
  const {
    actor,
    repo: { owner, repo },
    workflow,
    eventName,
    runId,
  } = context;

  // Capture a rate-limit snapshot at the start of the check for observability.
  await fetchAndLogRateLimit(github, "check_rate_limit_start");

  // Get workflow file name from GITHUB_WORKFLOW_REF (format: "owner/repo/.github/workflows/file.yml@ref")
  // or fall back to GITHUB_WORKFLOW (workflow name)
  const workflowRef = process.env.GITHUB_WORKFLOW_REF ?? "";
  // Extract workflow file from the ref (e.g., ".github/workflows/test.lock.yml@refs/heads/main")
  const workflowRefMatch = workflowRef.match(/\.github\/workflows\/([^@]+)/);
  let workflowId = workflow; // Default to workflow name

  if (workflowRef) {
    if (workflowRefMatch?.[1]) {
      workflowId = workflowRefMatch[1];
      core.info(`   Using workflow file: ${workflowId} (from GITHUB_WORKFLOW_REF)`);
    } else {
      core.info(`   Using workflow name: ${workflowId} (fallback - could not parse GITHUB_WORKFLOW_REF)`);
    }
  } else {
    core.info(`   Using workflow name: ${workflowId} (GITHUB_WORKFLOW_REF not available)`);
  }

  // Get configuration from environment variables
  // Use .trim() + || so that empty/whitespace-only values also fall back to defaults
  const maxRuns = Number(process.env.GH_AW_RATE_LIMIT_MAX?.trim() || "5");
  const windowMinutes = Number(process.env.GH_AW_RATE_LIMIT_WINDOW?.trim() || "60");
  if (!Number.isFinite(maxRuns) || !Number.isSafeInteger(maxRuns) || maxRuns <= 0 || !Number.isFinite(windowMinutes) || !Number.isSafeInteger(windowMinutes) || windowMinutes <= 0) {
    throw new Error("Rate limit maximum and window must be positive integers");
  }
  const eventsList = process.env.GH_AW_RATE_LIMIT_EVENTS?.trim() || "";
  // Default: admin, maintain, and write roles are exempt from rate limiting
  const ignoredRolesList = process.env.GH_AW_RATE_LIMIT_IGNORED_ROLES?.trim() || "admin,maintain,write";

  core.info(`🔍 Checking rate limit for user '${actor}' on workflow '${workflowId}'`);
  core.info(`   Configuration: max=${maxRuns} runs per ${windowMinutes} minutes`);
  core.info(`   Current event: ${eventName}`);

  // Check if user has an ignored role (exempt from rate limiting)
  const ignoredRoles = ignoredRolesList.split(",").map(r => r.trim());
  core.info(`   Ignored roles: ${ignoredRoles.join(", ")}`);

  try {
    // Check user's permission level in the repository
    const {
      data: { permission: userPermission },
    } = await github.rest.repos.getCollaboratorPermissionLevel({
      owner,
      repo,
      username: actor,
    });

    core.info(`   User '${actor}' has permission level: ${userPermission}`);

    // Map GitHub permission levels to role names
    // GitHub uses: admin, maintain, write, triage, read
    if (ignoredRoles.includes(userPermission)) {
      core.info(`✅ User '${actor}' has ignored role '${userPermission}'; skipping rate limit check`);
      core.setOutput("rate_limit_ok", "true");
      return;
    }
  } catch (error) {
    // If we can't check permissions, continue with rate limiting (fail-secure)
    core.warning(`⚠️ Could not check user permissions: ${getErrorMessage(error)}`);
    core.warning(`   Continuing with rate limit check for user '${actor}'`);
  }

  // Parse events to apply rate limiting to
  const limitedEvents = eventsList ? eventsList.split(",").map(e => e.trim()) : [];

  // If specific events are configured, check if current event should be limited
  if (limitedEvents.length > 0) {
    if (!limitedEvents.includes(eventName)) {
      core.info(`✅ Event '${eventName}' is not subject to rate limiting`);
      core.info(`   Rate limiting applies only to: ${limitedEvents.join(", ")}`);
      core.setOutput("rate_limit_ok", "true");
      return;
    }
    core.info(`   Event '${eventName}' is subject to rate limiting`);
  } else {
    // When no specific events are configured, apply rate limiting only to
    // known programmatic triggers. Allow all other events.
    if (!PROGRAMMATIC_EVENTS.includes(eventName)) {
      core.info(`✅ Event '${eventName}' is not a programmatic trigger; skipping rate limiting`);
      core.info(`   Rate limiting applies to: ${PROGRAMMATIC_EVENTS.join(", ")}`);
      core.setOutput("rate_limit_ok", "true");
      return;
    }

    core.info(`   Rate limiting applies to programmatic events: ${PROGRAMMATIC_EVENTS.join(", ")}`);
  }

  // Calculate time threshold
  const windowMs = windowMinutes * 60 * 1000;
  const thresholdTimestamp = Date.now() - windowMs;
  const thresholdISO = new Date(thresholdTimestamp).toISOString();

  core.info(`   Time window: runs created after ${thresholdISO}`);

  try {
    // Collect recent workflow runs by event type
    // This allows us to aggregate counts and short-circuit when max is exceeded
    let totalRecentRuns = 0;
    /** @type {Record<string, number>} */
    const runsPerEvent = {};

    core.info(`📊 Querying workflow runs for '${workflowId}'...`);

    // Query workflow runs (paginated if needed)
    let page = 1;
    let hasMore = true;
    const perPage = 100;

    while (hasMore && totalRecentRuns < maxRuns) {
      core.info(`   Fetching page ${page} (up to ${perPage} runs per page)...`);

      const response = await github.rest.actions.listWorkflowRuns({
        owner,
        repo,
        workflow_id: workflowId,
        per_page: perPage,
        page,
      });

      const runs = response.data.workflow_runs;
      core.info(`   Retrieved ${runs.length} runs from page ${page}`);

      if (runs.length === 0) {
        hasMore = false;
        break;
      }

      // Filter runs by actor and time window
      for (const run of runs) {
        // Stop processing if we've already exceeded the limit
        if (totalRecentRuns >= maxRuns) {
          core.info(`   Short-circuit: Already found ${totalRecentRuns} runs (>= max ${maxRuns})`);
          hasMore = false;
          break;
        }

        // Stop if run is older than the time window (runs are newest-first)
        const runCreatedAt = new Date(run.created_at);
        if (Number.isNaN(runCreatedAt.getTime())) {
          core.warning(`Skipping run ${run.id} with invalid creation date`);
          continue;
        }
        if (runCreatedAt.getTime() < thresholdTimestamp) {
          core.info(`   Stopping pagination - run ${run.id} created before threshold (${run.created_at})`);
          hasMore = false;
          break;
        }

        // Check if run is by the same actor
        if (run.actor?.login !== actor) {
          continue;
        }

        // Skip the current run (we're checking if we should allow THIS run)
        if (run.id === runId) {
          continue;
        }

        // Skip cancelled workflow runs (they don't count toward the rate limit)
        // GitHub uses conclusion: 'cancelled' with status: 'completed' for cancelled runs
        if (run.conclusion === "cancelled") {
          core.info(`   Skipping run ${run.id} - cancelled (conclusion: ${run.conclusion})`);
          continue;
        }

        // Skip runs that completed in less than 15 seconds (treat as cancelled/failed fast)
        if (run.created_at && run.updated_at) {
          const runStart = new Date(run.created_at);
          const runEnd = new Date(run.updated_at);
          const durationSeconds = (runEnd.getTime() - runStart.getTime()) / 1000;

          if (durationSeconds < 15) {
            core.info(`   Skipping run ${run.id} - ran for less than 15s (${durationSeconds.toFixed(1)}s)`);
            continue;
          }
        }

        // If specific events are configured, only count matching events
        const runEvent = run.event;
        if (limitedEvents.length > 0 && !limitedEvents.includes(runEvent)) {
          continue;
        }

        // Count this run
        totalRecentRuns++;
        runsPerEvent[runEvent] = (runsPerEvent[runEvent] ?? 0) + 1;

        core.info(`   ✓ Run #${run.run_number} (${run.id}) by ${run.actor?.login} - ` + `event: ${runEvent}, created: ${run.created_at}, status: ${run.status}`);
      }

      // Check if we should fetch more pages
      if (runs.length < perPage || totalRecentRuns >= maxRuns) {
        hasMore = false;
      } else {
        page++;
      }
    }

    // Log summary by event type
    core.info(`📈 Rate limit summary for user '${actor}':`);
    core.info(`   Total recent runs in last ${windowMinutes} minutes: ${totalRecentRuns}`);
    core.info(`   Maximum allowed: ${maxRuns}`);

    if (Object.keys(runsPerEvent).length > 0) {
      core.info(`   Breakdown by event type:`);
      for (const [event, count] of Object.entries(runsPerEvent)) {
        core.info(`   - ${event}: ${count} runs`);
      }
    }

    // Check if rate limit is exceeded
    if (totalRecentRuns >= maxRuns) {
      core.warning(`⚠️ Rate limit exceeded for user '${actor}' on workflow '${workflowId}'`);
      core.warning(`   User has triggered ${totalRecentRuns} runs in the last ${windowMinutes} minutes (max: ${maxRuns})`);
      core.warning(`   Cancelling current workflow run...`);

      // Cancel the current workflow run
      try {
        await github.rest.actions.cancelWorkflowRun({
          owner,
          repo,
          run_id: runId,
        });
        core.warning(`✅ Workflow run ${runId} cancelled successfully`);
      } catch (cancelError) {
        core.error(`❌ Failed to cancel workflow run: ${getErrorMessage(cancelError)}`);
        // Continue anyway - the rate limit output will still be set to false
      }

      core.setOutput("rate_limit_ok", "false");
      return;
    }

    // Rate limit not exceeded
    core.info(`✅ Rate limit check passed`);
    core.info(`   User '${actor}' has ${totalRecentRuns} runs in the last ${windowMinutes} minutes`);
    core.info(`   Remaining quota: ${maxRuns - totalRecentRuns} runs`);
    core.setOutput("rate_limit_ok", "true");
  } catch (error) {
    core.error(`❌ Rate limit check failed: ${getErrorMessage(error)}`);
    if (error instanceof Error && error.stack) {
      core.error(`   Stack trace: ${error.stack}`);
    }

    // On error, allow the workflow to proceed (fail-open)
    // This prevents rate limiting from blocking workflows due to API issues
    core.warning(`⚠️ Allowing workflow to proceed due to rate limit check error`);
    core.setOutput("rate_limit_ok", "true");
  }
}

module.exports = { main };
