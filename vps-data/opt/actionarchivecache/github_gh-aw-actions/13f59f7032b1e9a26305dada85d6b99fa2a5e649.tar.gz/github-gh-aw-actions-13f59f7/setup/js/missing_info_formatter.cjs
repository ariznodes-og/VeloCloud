// @ts-check
/// <reference types="@actions/github-script" />

/**
 * Missing Info Formatter Module
 *
 * This module provides functions to format missing_tool and missing_data
 * messages into HTML details sections for inclusion in safe output footers.
 */

/**
 * Escape markdown content to prevent injection
 * @param {string | null | undefined} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeMarkdown(text) {
  if (!text) return "";
  return text.replace(/\\/g, "\\\\").replace(/`/g, "\\`").replace(/\*/g, "\\*").replace(/_/g, "\\_").replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/**
 * Escape markdown content for table cells
 * @param {string | null | undefined} text - Text to escape
 * @returns {string} Escaped table-safe text
 */
function escapeMarkdownTableCell(text) {
  return escapeMarkdown(text).replace(/\|/g, "\\|").replace(/\r?\n/g, "<br>");
}

/**
 * Format missing_tool messages into markdown list items
 * @param {Array<{tool: string | null, reason: string, alternatives?: string | null}>} missingTools - Missing tool messages
 * @returns {string} Formatted markdown list
 */
function formatMissingTools(missingTools) {
  if (!missingTools || missingTools.length === 0) return "";

  const items = missingTools.map(item => `- **${escapeMarkdown(item.tool)}**: ${escapeMarkdown(item.reason)}`);
  const alternativesRows = missingTools.filter(item => item.alternatives).map(item => `| ${escapeMarkdownTableCell(item.tool)} | ${escapeMarkdownTableCell(item.alternatives)} |`);

  if (alternativesRows.length === 0) {
    return items.join("\n");
  }

  return `${items.join("\n")}\n\nAlternatives:\n\n| Tool | Alternative |\n| --- | --- |\n${alternativesRows.join("\n")}`;
}

/**
 * Format missing_data messages into markdown list items
 * @param {Array<{data_type: string, reason: string, context?: string, alternatives?: string}>} missingData - Missing data messages
 * @returns {string} Formatted markdown list
 */
function formatMissingData(missingData) {
  if (!missingData || missingData.length === 0) return "";

  const items = missingData.map(item => {
    let line = `- **${escapeMarkdown(item.data_type)}**: ${escapeMarkdown(item.reason)}`;
    if (item.context) {
      line += `\n  - *Context*: ${escapeMarkdown(item.context)}`;
    }
    if (item.alternatives) {
      line += `\n  - *Alternatives*: ${escapeMarkdown(item.alternatives)}`;
    }
    return line;
  });

  return items.join("\n");
}

/**
 * Format noop messages into markdown list items
 * @param {Array<{message: string}>} noopMessages - Noop messages
 * @returns {string} Formatted markdown list
 */
function formatNoopMessages(noopMessages) {
  if (!noopMessages?.length) return "";

  return noopMessages.map(item => `- ${escapeMarkdown(item.message)}`).join("\n");
}

/**
 * Format report_incomplete signals into markdown list items
 * @param {Array<{reason: string, details?: string}>} reportIncomplete - Report incomplete signals
 * @returns {string} Formatted markdown list
 */
function formatReportIncomplete(reportIncomplete) {
  if (!reportIncomplete || reportIncomplete.length === 0) return "";

  const items = reportIncomplete.map(item => {
    let line = `- ${escapeMarkdown(item.reason)}`;
    if (item.details) {
      line += `\n  - *Details*: ${escapeMarkdown(item.details)}`;
    }
    return line;
  });

  return items.join("\n");
}

/**
 * Generate HTML details section for missing tools
 * @param {Array<{tool: string, reason: string, alternatives?: string}>} missingTools - Missing tool messages
 * @returns {string} HTML details section or empty string
 */
function generateMissingToolsSection(missingTools) {
  if (!missingTools || missingTools.length === 0) return "";

  const content = formatMissingTools(missingTools);
  return `\n\n<details>\n<summary>Missing Tools</summary>\n\n${content}\n\n</details>`;
}

/**
 * Generate HTML details section for missing data
 * @param {Array<{data_type: string, reason: string, context?: string, alternatives?: string}>} missingData - Missing data messages
 * @returns {string} HTML details section or empty string
 */
function generateMissingDataSection(missingData) {
  if (!missingData || missingData.length === 0) return "";

  const content = formatMissingData(missingData);
  return `\n\n<details>\n<summary>Missing Data</summary>\n\n${content}\n\n</details>`;
}

/**
 * Generate HTML details section for noop messages
 * @param {Array<{message: string}>} noopMessages - Noop messages
 * @returns {string} HTML details section or empty string
 */
function generateNoopMessagesSection(noopMessages) {
  if (!noopMessages?.length) return "";

  const content = formatNoopMessages(noopMessages);
  return `\n\n<details>\n<summary>No-Op Messages</summary>\n\n${content}\n\n</details>`;
}

/**
 * Generate HTML details section for report_incomplete signals
 * @param {Array<{reason: string, details?: string}>} reportIncomplete - Report incomplete signals
 * @returns {string} HTML details section or empty string
 */
function generateReportIncompleteSection(reportIncomplete) {
  if (!reportIncomplete || reportIncomplete.length === 0) return "";

  const content = formatReportIncomplete(reportIncomplete);
  return `\n\n<details>\n<summary>Incomplete Signals</summary>\n\n${content}\n\n</details>`;
}

/**
 * Generate complete missing information sections for both tools and data
 * @param {{missingTools?: Array<any>, missingData?: Array<any>, noopMessages?: Array<any>, reportIncomplete?: Array<any>}} missings - Object containing missing tools, data, noop messages, and incomplete signals
 * @returns {string} Combined HTML details sections
 */
function generateMissingInfoSections(missings) {
  if (!missings) return "";

  const sections = [
    missings.missingTools && generateMissingToolsSection(missings.missingTools),
    missings.missingData && generateMissingDataSection(missings.missingData),
    missings.noopMessages && generateNoopMessagesSection(missings.noopMessages),
    missings.reportIncomplete && generateReportIncompleteSection(missings.reportIncomplete),
  ];

  return sections.filter(Boolean).join("");
}

module.exports = {
  escapeMarkdown,
  formatMissingTools,
  formatMissingData,
  formatNoopMessages,
  formatReportIncomplete,
  generateMissingToolsSection,
  generateMissingDataSection,
  generateNoopMessagesSection,
  generateReportIncompleteSection,
  generateMissingInfoSections,
};
