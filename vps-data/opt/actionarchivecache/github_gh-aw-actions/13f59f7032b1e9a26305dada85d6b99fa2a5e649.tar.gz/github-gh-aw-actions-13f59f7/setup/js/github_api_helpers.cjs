// @ts-check
/// <reference types="@actions/github-script" />

// @safe-outputs-exempt SEC-004: low-level GraphQL helper; body is sanitized by callers (add_comment.cjs, add_reaction_and_edit_comment.cjs) before it reaches this layer.

/**
 * GitHub API helper functions
 * Provides common GitHub API operations with consistent error handling
 */

const { getErrorMessage } = require("./error_helpers.cjs");

/**
 * @typedef {Object} GraphQLErrorHints
 * @property {string} [insufficientScopesHint] - Message shown when INSUFFICIENT_SCOPES error type is present
 * @property {string} [notFoundHint] - Message shown when NOT_FOUND error type is present
 * @property {(msg: string) => boolean} [notFoundPredicate] - Additional condition for showing the NOT_FOUND hint (receives the error message string)
 */

/**
 * Log detailed GraphQL error information for diagnosing API failures.
 * Surfaces the errors array, type codes, paths, HTTP status, and optional domain-specific hints.
 *
 * @param {Error & { errors?: Array<{ type?: string, message: string, path?: unknown, locations?: unknown }>, request?: unknown, data?: unknown, status?: number }} error - GraphQL error
 * @param {string} operation - Human-readable description of the failing operation
 * @param {GraphQLErrorHints} [hints] - Optional domain-specific hint messages
 */
function logGraphQLError(error, operation, hints = {}) {
  core.info(`GraphQL error during: ${operation}`);
  core.info(`Message: ${getErrorMessage(error)}`);

  const errorList = Array.isArray(error.errors) ? error.errors : [];
  const hasInsufficientScopes = errorList.some(e => e?.type === "INSUFFICIENT_SCOPES");
  const hasNotFound = errorList.some(e => e?.type === "NOT_FOUND");

  if (hasInsufficientScopes && hints.insufficientScopesHint) {
    core.info(hints.insufficientScopesHint);
  }

  if (hasNotFound && hints.notFoundHint) {
    const predicatePasses = !hints.notFoundPredicate || hints.notFoundPredicate(getErrorMessage(error));
    if (predicatePasses) {
      core.info(hints.notFoundHint);
    }
  }

  if (error.errors) {
    core.info(`Errors array (${error.errors.length} error(s)):`);
    error.errors.forEach((err, idx) => {
      core.info(`  [${idx + 1}] ${err.message}`);
      if (err.type) core.info(`      Type: ${err.type}`);
      if (err.path) core.info(`      Path: ${JSON.stringify(err.path)}`);
      if (err.locations) core.info(`      Locations: ${JSON.stringify(err.locations)}`);
    });
  }

  if (error.status) core.info(`HTTP status: ${error.status}`);
  if (error.request) core.info("Request details omitted");
  if (error.data) core.info("Response data omitted");
}

/**
 * Get file content from GitHub repository using the API
 * @param {Object} github - GitHub API client (@actions/github)
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {string} path - File path within the repository
 * @param {string} ref - Git reference (branch, tag, or commit SHA)
 * @returns {Promise<{content: string|null, errorStatus: number|null}>} File content and HTTP error status (if any)
 */
async function getFileContent(github, owner, repo, path, ref) {
  try {
    const response = await github.rest.repos.getContent({
      owner,
      repo,
      path,
      ref,
    });

    // Handle case where response is an array (directory listing)
    if (Array.isArray(response.data)) {
      core.info(`Path ${path} is a directory, not a file`);
      return { content: null, errorStatus: null };
    }

    // Check if this is a file (not a symlink or submodule)
    if (response.data.type !== "file") {
      core.info(`Path ${path} is not a file (type: ${response.data.type})`);
      return { content: null, errorStatus: null };
    }

    // Decode base64 content
    if (response.data.encoding === "base64" && response.data.content) {
      return { content: Buffer.from(response.data.content, "base64").toString("utf8"), errorStatus: null };
    }

    return { content: response.data.content || null, errorStatus: null };
  } catch (error) {
    const errorMessage = getErrorMessage(error);
    core.info(`Could not fetch content for ${path}: ${errorMessage}`);
    return { content: null, errorStatus: error.status ?? null };
  }
}

/**
 * Fetches all labels from a repository, paginating through all pages.
 * @param {any} githubClient - GitHub API client
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @returns {Promise<Array<{id: string, name: string}>>} All repository labels
 */
async function fetchAllRepoLabels(githubClient, owner, repo) {
  const labelsQuery = `
    query($owner: String!, $repo: String!, $cursor: String) {
      repository(owner: $owner, name: $repo) {
        labels(first: 100, after: $cursor) {
          nodes {
            id
            name
          }
          pageInfo {
            hasNextPage
            endCursor
          }
        }
      }
    }
  `;

  const allLabels = /** @type {Array<{id: string, name: string}>} */ [];
  let cursor = /** @type {string | null} */ null;
  let hasNextPage = true;

  while (hasNextPage) {
    const queryResult = await githubClient.graphql(labelsQuery, { owner, repo, cursor });
    const labelsPage = queryResult?.repository?.labels;
    const nodes = labelsPage?.nodes || [];
    allLabels.push(...nodes);
    hasNextPage = labelsPage?.pageInfo?.hasNextPage ?? false;
    cursor = labelsPage?.pageInfo?.endCursor ?? null;
  }

  return allLabels;
}

/**
 * Resolves the top-level parent comment node ID for GitHub Discussion replies.
 * GitHub Discussions only supports two nesting levels: top-level comments and one level of replies.
 * If the given comment is itself a reply (has a replyTo parent), the parent's node ID is returned
 * so that replyToId always points to a top-level comment.
 *
 * @param {Object} github - GitHub API client (must support graphql)
 * @param {string|null|undefined} commentNodeId - The node_id of the triggering comment
 * @returns {Promise<string|null|undefined>} The node ID to use as replyToId (parent if reply, otherwise the original)
 */
async function resolveTopLevelDiscussionCommentId(github, commentNodeId) {
  if (!commentNodeId) {
    return commentNodeId;
  }
  try {
    const result = await github.graphql(
      `query($nodeId: ID!) {
        node(id: $nodeId) {
          ... on DiscussionComment {
            replyTo {
              id
            }
          }
        }
      }`,
      { nodeId: commentNodeId }
    );
    return result?.node?.replyTo?.id ?? commentNodeId;
  } catch (error) {
    logGraphQLError(/** @type {Error & { errors?: Array<{ type?: string, message: string, path?: unknown, locations?: unknown }>, request?: unknown, data?: unknown, status?: number }} */ error, "resolving top-level discussion comment");
    return commentNodeId;
  }
}

/**
 * Type guard for a resolved REST endpoint descriptor, shared by handlers that
 * choose between a REST call ({route, params}) and a GraphQL/discussion path.
 * @param {unknown} endpoint
 * @returns {endpoint is { route: string, params: Record<string, unknown> }}
 */
function isRestEndpoint(endpoint) {
  return typeof endpoint === "object" && endpoint !== null && "route" in endpoint && "params" in endpoint;
}

/**
 * Create a discussion comment with optional threaded reply target.
 * @param {Object} github - GitHub API client (must support graphql)
 * @param {string} discussionId - Discussion GraphQL node ID
 * @param {string} body - Comment body
 * @param {string|null|undefined} [replyToId] - Optional top-level discussion comment node ID for threading
 * @returns {Promise<{id: string, url: string}>}
 */
async function createDiscussionComment(github, discussionId, body, replyToId) {
  const mutation = replyToId
    ? /* GraphQL */ `
        mutation ($dId: ID!, $body: String!, $replyToId: ID!) {
          addDiscussionComment(input: { discussionId: $dId, body: $body, replyToId: $replyToId }) {
            comment {
              id
              url
            }
          }
        }
      `
    : /* GraphQL */ `
        mutation ($dId: ID!, $body: String!) {
          addDiscussionComment(input: { discussionId: $dId, body: $body }) {
            comment {
              id
              url
            }
          }
        }
      `;

  const variables = { dId: discussionId, body, ...(replyToId ? { replyToId } : {}) };
  const result = await github.graphql(mutation, variables);
  return result.addDiscussionComment.comment;
}

module.exports = {
  createDiscussionComment,
  fetchAllRepoLabels,
  getFileContent,
  isRestEndpoint,
  logGraphQLError,
  resolveTopLevelDiscussionCommentId,
};
