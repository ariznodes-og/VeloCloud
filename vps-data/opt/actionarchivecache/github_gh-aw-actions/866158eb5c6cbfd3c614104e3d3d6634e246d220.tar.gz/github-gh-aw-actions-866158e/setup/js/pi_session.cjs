// @ts-check

const { isDeepStrictEqual } = require("node:util");
const { createSessionEvent, isSessionEvent, normalizeAgentSession, transformFlatSessionEntries, isMetric, isTokenCount, sessionScopeKey } = require("./agent_session.cjs");

/** @typedef {import("./types/agent_session").SessionEvent} SessionEvent */
/** @typedef {{content: string, segments: SessionEvent[]}} TextState */
/** @typedef {{text: Map<number, TextState>, thinking: Map<number, TextState>, calls: Map<number, SessionEvent>, blocks: Map<number, SessionEvent>, errors: unknown[], finalized: boolean, identity?: string}} MessageState */

const PI_SESSION_EVENT_TYPES = {
  agent_start: "session.start",
  agent_settled: "session.idle",
  auto_retry_start: "session.retry_start",
  auto_retry_end: "session.retry_end",
  compaction_start: "session.compaction_start",
  compaction_end: "session.compaction_end",
  queue_update: "session.queue_update",
  entry_appended: "session.entry_appended",
  thinking_level_changed: "session.reasoning_effort_changed",
  summarization_retry_scheduled: "session.summarization_retry_scheduled",
  summarization_retry_attempt_start: "session.summarization_retry_attempt_start",
  summarization_retry_finished: "session.summarization_retry_finished",
};

const PI_LEGACY_SUBAGENT_TYPES = {
  "pi.subagent_dispatch": "gh_aw_subagent_dispatch",
  "pi.subagent_event": "gh_aw_subagent_event",
  "pi.subagent_result": "gh_aw_subagent_result",
};

/** @param {any} record @returns {boolean} */
function isLegacyPiObservation(record) {
  if (!isSessionEvent(record) || (record.data.sourceEngine !== undefined && record.data.sourceEngine !== "pi")) return false;
  return (
    ["pi.message_snapshot", "pi.message_update", "pi.tool_execution_update", "pi.error"].includes(record.type) ||
    Object.hasOwn(PI_LEGACY_SUBAGENT_TYPES, record.type) ||
    (record.type.startsWith("pi.") && Object.hasOwn(PI_SESSION_EVENT_TYPES, record.type.slice(3)))
  );
}

/**
 * Normalize saved Pi observations without replaying snapshots as new messages.
 * @param {any[]} records
 * @param {(event: SessionEvent) => SessionEvent} [mapLegacyEvent] Applied only to converted historical observations.
 * @returns {any[]}
 */
function normalizePiObservations(records, mapLegacyEvent) {
  return records.some(isLegacyPiObservation) ? transformPiV3Entries(records, mapLegacyEvent) : records;
}

/**
 * @param {any} record
 * @param {Map<string, {toolCallId?: string, toolName?: string}>} calls
 * @returns {any}
 */
function normalizeLegacyPiObservation(record, calls) {
  if (!isLegacyPiObservation(record)) return record;
  const data = { ...record.data, sourceEngine: "pi" };
  const scope = `${sessionScopeKey(record)}:${JSON.stringify(data.parentToolCallId !== undefined ? data.parentToolCallId : record.parentToolCallId)}:`;
  if (Object.hasOwn(PI_LEGACY_SUBAGENT_TYPES, record.type)) return { ...record, ...data, type: PI_LEGACY_SUBAGENT_TYPES[record.type] };
  if (record.type === "pi.message_snapshot") {
    const message = record.message;
    for (const key of ["role", "model", "toolCallId", "toolName"]) if (data[key] === undefined && message?.[key] !== undefined) data[key] = message[key];
    if (data.role === "assistant") {
      for (const key of calls.keys()) if (key.startsWith(scope)) calls.delete(key);
    }
    const messageId = message?.id !== undefined ? message.id : message?.responseId;
    if (data.messageId === undefined && messageId !== undefined) data.messageId = messageId;
    if (data.usageSnapshot === undefined && data.usage !== undefined) data.usageSnapshot = data.usage;
    return createSessionEvent(record, "session.info", { ...data, sourceType: "message_snapshot" });
  }
  if (record.type === "pi.tool_execution_update") {
    if (data.output === undefined && Object.hasOwn(data, "partialResult")) data.output = data.partialResult;
    return createSessionEvent(record, "tool.execution_update", { ...data, partial: true, sourceType: "tool_execution_update" });
  }
  if (record.type === "pi.message_update") {
    if (!["toolcall_start", "toolcall_delta", "toolcall_end"].includes(data.type)) return createSessionEvent(record, "assistant.message_update", { ...data, sourceType: "message_update" });
    const key = `${scope}${data.contentIndex}`;
    const canCorrelate = isTokenCount(data.contentIndex);
    const previous = data.type === "toolcall_start" || !canCorrelate ? {} : calls.get(key) || {};
    const id = data.toolCallId !== undefined ? data.toolCallId : data.toolCall?.id !== undefined ? data.toolCall.id : data.type === "toolcall_start" ? data.id : undefined;
    const name = data.toolName !== undefined ? data.toolName : data.toolCall?.name;
    if (id !== undefined) data.toolCallId = id;
    else if (data.toolCallId === undefined && previous.toolCallId !== undefined) data.toolCallId = previous.toolCallId;
    if (name !== undefined) data.toolName = name;
    else if (data.toolName === undefined && previous.toolName !== undefined) data.toolName = previous.toolName;
    if (data.type === "toolcall_start") calls.delete(key);
    if (canCorrelate && (typeof data.toolCallId === "string" || typeof data.toolName === "string")) calls.set(key, { toolCallId: data.toolCallId, toolName: data.toolName });
    if (data.type === "toolcall_delta" && typeof data.delta === "string") {
      data.input = data.delta;
      data.delta = true;
    } else if (data.input === undefined && data.toolCall && Object.hasOwn(data.toolCall, "arguments")) data.input = data.toolCall.arguments;
    if (data.usageSnapshot === undefined && data.usage !== undefined) data.usageSnapshot = data.usage;
    if (data.type === "toolcall_end") calls.delete(key);
    return createSessionEvent(record, "tool.execution_update", { ...data, partial: true, sourceType: data.type });
  }
  if (record.type === "pi.error") return createSessionEvent(record, "session.error", data);
  return createSessionEvent(record, PI_SESSION_EVENT_TYPES[record.type.slice(3)], data);
}

/** @param {any} message @returns {string|undefined} */
function messageIdentity(message) {
  const id = message?.id ?? message?.responseId;
  if (id !== undefined) return JSON.stringify([message.role, id]);
  if (message?.timestamp !== undefined) return JSON.stringify([message.role, message.timestamp]);
  return undefined;
}

/** @returns {MessageState} */
function newMessageState() {
  return { text: new Map(), thinking: new Map(), calls: new Map(), blocks: new Map(), errors: [], finalized: false };
}

/** @param {any} result @returns {boolean} */
function isPiResultError(result) {
  return !!(
    result &&
    (result.isError === true ||
      result.is_error === true ||
      result.status === "error" ||
      result.status === "failed" ||
      result.error != null ||
      [result.exitCode, result.details?.exitCode, result.structuredContent?.exitCode].some(code => typeof code === "number" && code !== 0))
  );
}

/**
 * Pi repeats complete messages at message_end, turn_end and agent_end. Text deltas
 * are observations, whereas those envelopes are snapshots of the same message.
 * @param {Array<any>} records
 * @param {(event: SessionEvent) => SessionEvent} [mapLegacyEvent]
 * @returns {SessionEvent[]}
 */
function transformPiV3Entries(records, mapLegacyEvent = event => event) {
  records = records.filter(record => record && typeof record === "object" && !Array.isArray(record));
  /** @type {SessionEvent[]} */
  const events = [];
  const subagentInvocations = new Map();
  const subagentInvocationCounts = new Map();
  const subagentRecords = new Map();
  const subagentEvents = new Map();
  const subagentRequests = new Map();
  const legacyCallIds = new Map();
  const executionEnds = new Set(records.filter(r => r.type === "tool_execution_end" && r.toolCallId !== undefined).map(r => r.toolCallId));
  const calls = new Map();
  const executionStarts = new Set();
  const completions = new Set();
  /** @type {Map<string, MessageState>} */
  const messageStates = new Map();
  /** @type {Array<{message: any, state: MessageState}>} */
  const snapshots = [];
  let assistantState = newMessageState();
  let activeState = assistantState;
  let partialAssistant = false;
  let legacyObservation = false;
  /**
   * @template {SessionEvent["type"]} T
   * @param {any} raw
   * @param {T} type
   * @param {import("./types/agent_session").SessionEventData<T>} data
   */
  const emit = (raw, type, data, metadata = {}) => {
    const event = createSessionEvent(raw, type, data);
    Object.assign(event, metadata);
    events.push(legacyObservation ? mapLegacyEvent(event) : event);
    return event;
  };
  const invocationIdentity = (raw, dispatch) => {
    const agentName = raw.agent ?? raw.agentName ?? "unknown";
    const supplied = raw.invocation_id ?? raw.invocationId;
    if (typeof supplied === "string" && supplied !== "") {
      if (dispatch) subagentInvocations.set(agentName, supplied);
      else if (raw.type === "gh_aw_subagent_result" && subagentInvocations.get(agentName) === supplied) subagentInvocations.delete(agentName);
      return supplied;
    }
    if (!dispatch && subagentInvocations.has(agentName)) return subagentInvocations.get(agentName);
    if (!dispatch) return `legacy:pi:${agentName}:unknown`;
    const count = (subagentInvocationCounts.get(agentName) ?? 0) + 1;
    subagentInvocationCounts.set(agentName, count);
    const identity = `legacy:pi:${agentName}:${count}`;
    subagentInvocations.set(agentName, identity);
    return identity;
  };
  const emitSubagentRequest = (raw, invocationId) => {
    const message = raw.event?.message;
    if (!message || message.role !== "assistant") return;
    const failed = ["error", "aborted"].includes(message.stopReason) || typeof message.errorMessage === "string";
    const usage = message.usage && typeof message.usage === "object" && !Array.isArray(message.usage) ? message.usage : {};
    const hasTokens = ["input", "output", "cacheRead", "cacheWrite"].some(key => Number.isSafeInteger(usage[key]) && usage[key] >= 0);
    if (failed && !hasTokens) return;
    const model = message.responseModel ?? message.model;
    if (typeof model !== "string" || model === "") return;
    const data = {
      invocationId,
      agentName: raw.agent ?? raw.agentName ?? "unknown",
      model,
      ...(message.requestId !== undefined ? { requestId: message.requestId } : {}),
    };
    for (const [source, target] of [
      ["input", "inputTokens"],
      ["output", "outputTokens"],
      ["cacheRead", "cacheReadTokens"],
      ["cacheWrite", "cacheWriteTokens"],
    ]) {
      const value = usage[source] ?? usage[target];
      if (Number.isSafeInteger(value) && value >= 0) data[target] = value;
    }
    const key = JSON.stringify([invocationId, messageIdentity(message) ?? message]);
    const previous = subagentRequests.get(key);
    if (previous) Object.assign(previous.data, data);
    else subagentRequests.set(key, emit(raw, "subagent.request", data, { agentId: invocationId }));
  };

  const emitText = (raw, state, kind, index, text, delta, role = "assistant", metadata = {}) => {
    if (typeof text !== "string") return;
    const previous = state[kind].get(index) ?? { content: "", segments: [] };
    const content = delta ? previous.content + text : text;
    const suffix = delta ? text : content.startsWith(previous.content) ? content.slice(previous.content.length) : undefined;
    let offset = 0;
    for (const [position, segment] of previous.segments.entries()) {
      const value = suffix === undefined ? content.slice(offset, position === previous.segments.length - 1 ? undefined : offset + segment.data.content.length) : segment.data.content;
      offset += segment.data.content.length;
      Object.assign(segment.data, structuredClone(metadata), { content: value });
    }
    if (suffix !== undefined && (suffix !== "" || previous.segments.length === 0)) {
      const segment = previous.segments.at(-1);
      // Coalesce only adjacent observations, never across another channel or event.
      if (segment && events.at(-1) === segment) {
        segment.data.content += suffix;
      } else {
        previous.segments.push(emit(raw, role === "user" ? "user.message" : kind === "thinking" ? "assistant.reasoning" : "assistant.message", { ...metadata, content: suffix }));
      }
    }
    previous.content = content;
    state[kind].set(index, previous);
  };

  const reconcileContentIndex = (state, index, kind) => {
    const history = [];
    const removed = new Set();
    for (const [category, values] of [
      ["text", state.text],
      ["thinking", state.thinking],
      ["calls", state.calls],
      ["blocks", state.blocks],
    ]) {
      if (category === kind) continue;
      const previous = values.get(index);
      if (!previous) continue;
      values.delete(index);
      const previousEvents = category === "text" || category === "thinking" ? previous.segments : [previous];
      for (const event of previousEvents) {
        // Replaced message observations must not erase an observed execution.
        if (!executionStarts.has(event)) removed.add(event);
        if (Array.isArray(event.data.nativeSnapshots)) history.push(...structuredClone(event.data.nativeSnapshots));
      }
      const content = category === "text" || category === "thinking" ? previous.content : Object.hasOwn(previous.data, "content") ? previous.data.content : previous.data.input;
      if (content !== undefined && ((category !== "text" && category !== "thinking") || previous.segments.length > 0)) {
        history.push({ content: structuredClone(content) });
      }
      if (category === "calls" && !executionStarts.has(previous) && previous.data.toolCallId !== undefined && calls.get(previous.data.toolCallId) === previous) {
        calls.delete(previous.data.toolCallId);
      }
    }
    if (removed.size) {
      for (let eventIndex = events.length - 1; eventIndex >= 0; eventIndex--) {
        if (removed.has(events[eventIndex])) events.splice(eventIndex, 1);
      }
    }
    return history.length ? history : undefined;
  };

  const emitCall = (raw, part, state = assistantState, index = raw.assistantMessageEvent?.contentIndex ?? 0) => {
    const indexed = state.calls.get(index);
    const previous = part.id !== undefined ? (calls.get(part.id) ?? (indexed?.data.toolCallId === undefined ? indexed : undefined)) : indexed;
    if (previous) {
      Object.assign(previous.data, structuredClone(part));
      if (part.id !== undefined) {
        previous.data.toolCallId = part.id;
        calls.set(part.id, previous);
      }
      if (part.name !== undefined) previous.data.toolName = part.name;
      if (Object.hasOwn(part, "arguments")) {
        previous.data.arguments = structuredClone(part.arguments);
        previous.data.input = structuredClone(part.arguments);
      }
      state.calls.set(index, previous);
      return previous;
    }
    const event = emit(raw, "tool.execution_start", { ...part, toolCallId: part.id, toolName: part.name, input: part.arguments });
    if (part.id !== undefined) calls.set(part.id, event);
    state.calls.set(index, event);
    return event;
  };

  const emitCompletion = (raw, message) => {
    const id = message.toolCallId;
    if (id !== undefined && (executionEnds.has(id) || completions.has(id))) return;
    if (id !== undefined) completions.add(id);
    emit(raw, "tool.execution_complete", {
      ...message,
      toolCallId: id,
      toolName: message.toolName,
      output: message.content,
      success: message.isError === true || isPiResultError(message) ? false : message.isError === false ? true : undefined,
    });
  };

  const emitMessage = (raw, message, fallback) => {
    if (!message || typeof message.role !== "string") return;
    if (!["assistant", "user", "toolResult"].includes(message.role)) {
      if (!snapshots.some(snapshot => isDeepStrictEqual(snapshot.message, message))) {
        snapshots.push({ message: structuredClone(message), state: fallback });
        emit(raw, "session.info", { sourceType: "message_snapshot", role: message.role, content: message });
      }
      return;
    }
    if (message.role === "toolResult") {
      emitCompletion(raw, message);
      return;
    }
    const messageID = messageIdentity(message);
    const identity = messageID ?? (raw.id !== undefined && raw.type !== "agent_end" ? JSON.stringify(["record", raw.id]) : undefined);
    const duplicate = snapshots.some(snapshot => snapshot.state === fallback && snapshot.message.role === message.role && isDeepStrictEqual(snapshot.message.content, message.content));
    const distinct = fallback.finalized && ((messageID !== undefined && fallback.identity !== undefined && messageID !== fallback.identity) || (raw.type === "message_end" && !duplicate));
    const state = (identity !== undefined && messageStates.get(identity)) || (distinct ? newMessageState() : fallback);
    if (identity !== undefined) messageStates.set(identity, state);
    if (messageID !== undefined) state.identity = messageID;
    if (message.role === "assistant") assistantState = state;
    const content = typeof message.content === "string" ? [{ type: "text", text: message.content }] : message.content;
    const parts = Array.isArray(content) ? content : content !== undefined ? [content] : [];
    for (const [index, part] of parts.entries()) {
      const kind = part?.type === "text" ? "text" : part?.type === "thinking" ? "thinking" : part?.type === "toolCall" ? "calls" : "blocks";
      const nativeSnapshots = reconcileContentIndex(state, index, kind);
      const metadata = nativeSnapshots && part && typeof part === "object" && !Array.isArray(part) ? { ...part, nativeSnapshots: [...(Array.isArray(part.nativeSnapshots) ? part.nativeSnapshots : []), ...nativeSnapshots] } : part;
      if (part?.type === "text" || part?.type === "thinking") {
        emitText(raw, state, part.type, index, part.type === "text" ? part.text : part.thinking, false, message.role, metadata);
      } else if (part?.type === "toolCall") emitCall(raw, metadata, state, index);
      else {
        const previous = state.blocks.get(index);
        if (previous) {
          if (!isDeepStrictEqual(previous.data.content, part)) {
            (previous.data.nativeSnapshots ??= []).push({ content: structuredClone(previous.data.content) });
            previous.data.content = structuredClone(part);
          }
        } else
          state.blocks.set(
            index,
            emit(raw, message.role === "user" ? "user.message" : "assistant.message", {
              content: part,
              contentIndex: index,
              ...(nativeSnapshots ? { nativeSnapshots } : {}),
            })
          );
      }
    }
    const messageMetadata = { ...message };
    delete messageMetadata.content;
    const metadata = {
      messageMetadata,
      ...(message.model !== undefined ? { model: message.model } : {}),
      ...((message.id ?? message.responseId) !== undefined ? { messageId: message.id ?? message.responseId } : {}),
    };
    for (const segments of [...state.text.values(), ...state.thinking.values()]) {
      for (const event of segments.segments) Object.assign(event.data, structuredClone(metadata));
    }
    for (const event of state.calls.values()) Object.assign(event.data, structuredClone(metadata));
    for (const event of state.blocks.values()) Object.assign(event.data, structuredClone(metadata));
    if (!snapshots.some(snapshot => snapshot.state === state && isDeepStrictEqual(snapshot.message, message))) snapshots.push({ message: structuredClone(message), state });
    if (raw.type === "message_end" || raw.type === "turn_end") state.finalized = true;
    if (message.errorMessage !== undefined && !state.errors.some(error => isDeepStrictEqual(error, message.errorMessage))) {
      state.errors.push(structuredClone(message.errorMessage));
      emit(raw, "session.error", { error: message.errorMessage, model: message.model });
    }
  };

  for (const record of records) {
    legacyObservation = isLegacyPiObservation(record);
    const raw = normalizeLegacyPiObservation(record, legacyCallIds);
    if (isSessionEvent(raw)) {
      const event = structuredClone(raw);
      events.push(legacyObservation ? mapLegacyEvent(event) : event);
      if (event.type === "tool.execution_start") {
        executionStarts.add(event);
        if (event.data.toolCallId !== undefined) calls.set(event.data.toolCallId, event);
      }
    } else if (raw.type === "gh_aw_subagent_dispatch") {
      const invocationId = invocationIdentity(raw, true);
      const agentName = raw.agent ?? raw.agentName ?? "unknown";
      emit(
        raw,
        "subagent.started",
        {
          invocationId,
          agentName,
          ...((raw.requested_model ?? raw.requestedModel) ? { model: raw.requested_model ?? raw.requestedModel } : {}),
          ...((raw.resolved_model ?? raw.resolvedModel) ? { resolvedModel: raw.resolved_model ?? raw.resolvedModel } : {}),
        },
        { agentId: invocationId }
      );
      if (raw.resolved_model ?? raw.resolvedModel) {
        emit(raw, "subagent.configured", { invocationId, model: raw.resolved_model ?? raw.resolvedModel }, { agentId: invocationId });
      }
    } else if (raw.type === "gh_aw_subagent_event") {
      const invocationId = invocationIdentity(raw, false);
      emitSubagentRequest(raw, invocationId);
      if (raw.event && typeof raw.event === "object" && !Array.isArray(raw.event) && typeof raw.event.type === "string") {
        const childRecords = subagentRecords.get(invocationId) ?? [];
        childRecords.push({
          ...structuredClone(raw.event),
          ...(raw.provenance !== undefined ? { provenance: structuredClone(raw.provenance) } : {}),
        });
        subagentRecords.set(invocationId, childRecords);
        const previous = subagentEvents.get(invocationId) ?? [];
        // Replay only this child's observations so repeated snapshots reconcile
        // without sharing tool/message identities with the parent or other children.
        const childEvents = transformPiV3Entries(childRecords).map(event => ({
          ...event,
          agentId: event.agentId ?? invocationId,
          data: { ...event.data, agentId: event.data.agentId ?? invocationId },
        }));
        for (let index = 0; index < previous.length; index++) {
          const position = events.indexOf(previous[index]);
          if (position >= 0) {
            if (index < childEvents.length) events[position] = childEvents[index];
            else events.splice(position, 1);
          }
        }
        events.push(...childEvents.slice(previous.length));
        subagentEvents.set(invocationId, childEvents);
      } else emit(raw, "session.info", { sourceType: raw.type, content: raw.event }, { agentId: invocationId });
    } else if (raw.type === "gh_aw_subagent_result") {
      const invocationId = invocationIdentity(raw, false);
      const failed = raw.outcome !== "completed";
      const data = {
        invocationId,
        agentName: raw.agent ?? raw.agentName ?? "unknown",
        outcome: raw.outcome,
        ...((raw.error_code ?? raw.errorCode) ? { errorCode: raw.error_code ?? raw.errorCode } : {}),
        ...(raw.error ? { error: raw.error } : {}),
      };
      emit(raw, failed ? "subagent.failed" : "subagent.completed", data, { agentId: invocationId });
      if (subagentInvocations.get(raw.agent ?? raw.agentName ?? "unknown") === invocationId) {
        subagentInvocations.delete(raw.agent ?? raw.agentName ?? "unknown");
      }
    } else if (raw.type === "session") emit(raw, "session.init", { sourceEngine: "pi", sessionId: raw.id, cwd: raw.cwd, model: raw.model });
    else if (raw.type === "turn_start") {
      assistantState = activeState = newMessageState();
      partialAssistant = false;
    } else if (raw.type === "message_start") {
      activeState = newMessageState();
      if (raw.message?.role === "assistant") {
        assistantState = activeState;
        partialAssistant = true;
      }
      emitMessage(raw, raw.message, activeState);
    } else if (raw.type === "message_update") {
      if (assistantState.finalized) assistantState = activeState = newMessageState();
      const update = raw.assistantMessageEvent;
      const kind = update?.type?.startsWith("thinking_") ? "thinking" : "text";
      if (update?.type === "text_delta" || update?.type === "thinking_delta") {
        partialAssistant = true;
        emitText(raw, assistantState, kind, update.contentIndex ?? 0, update.delta, true);
      } else if (update?.type === "text_end" || update?.type === "thinking_end") {
        emitText(raw, assistantState, kind, update.contentIndex ?? 0, update.content, false);
      } else if (update?.type === "toolcall_end" && update.toolCall) emitCall(raw, update.toolCall);
      else if (update?.type === "toolcall_start") emitCall(raw, { id: update.id, name: update.toolName });
      else if (update?.type === "toolcall_delta" && typeof update.delta === "string") {
        const call = assistantState.calls.get(update.contentIndex ?? 0);
        if (call) call.data.argumentText = (call.data.argumentText ?? "") + update.delta;
        else emit(raw, "tool.execution_update", { input: update.delta, delta: true, partial: true, contentIndex: update.contentIndex });
      } else if (update?.type === "done" || update?.type === "error") emitMessage(raw, update.message ?? update.error, assistantState);
      else if (update && !["start", "text_start", "thinking_start"].includes(update.type)) emit(raw, "assistant.message_update", { ...update, content: update, usage: raw.usage });
    } else if (raw.type === "message" && raw.message) emitMessage(raw, raw.message, newMessageState());
    else if (raw.type === "message_end") emitMessage(raw, raw.message, raw.message?.role === "assistant" ? assistantState : activeState);
    else if (raw.type === "turn_end") {
      emitMessage(raw, raw.message, assistantState);
      for (const result of raw.toolResults ?? []) emitCompletion(raw, result);
      assistantState = newMessageState();
      partialAssistant = false;
    } else if (raw.type === "tool_execution_start") {
      executionStarts.add(
        emitCall(raw, { id: raw.toolCallId, name: raw.toolName, ...(raw.parentToolCallId !== undefined ? { parentToolCallId: raw.parentToolCallId } : {}), ...(Object.hasOwn(raw, "args") ? { arguments: raw.args } : {}) }, newMessageState())
      );
    } else if (raw.type === "tool_execution_end") {
      if (raw.toolCallId !== undefined && completions.has(raw.toolCallId)) continue;
      if (raw.toolCallId !== undefined) completions.add(raw.toolCallId);
      emit(raw, "tool.execution_complete", {
        toolCallId: raw.toolCallId,
        toolName: raw.toolName,
        parentToolCallId: raw.parentToolCallId,
        result: raw.result,
        output: raw.result,
        error: raw.error ?? raw.result?.error,
        success: raw.isError === true || raw.error != null || isPiResultError(raw.result) ? false : raw.isError === false ? true : undefined,
        durationMs: isMetric(raw.durationMs) ? raw.durationMs : undefined,
      });
    } else if (raw.type === "tool_execution_update")
      emit(raw, "tool.execution_update", { toolCallId: raw.toolCallId, toolName: raw.toolName, parentToolCallId: raw.parentToolCallId, input: raw.args, output: raw.partialResult, partial: true });
    else if (Object.hasOwn(PI_SESSION_EVENT_TYPES, raw.type)) {
      const { type, ...data } = raw;
      emit(raw, PI_SESSION_EVENT_TYPES[type], data);
    } else if (raw.type === "agent_end") {
      const consumed = new Set();
      const messages = raw.messages ?? [];
      const lastAssistant = messages.findLastIndex(message => message?.role === "assistant");
      for (const [position, message] of messages.entries()) {
        const index = snapshots.findIndex((snapshot, i) => !consumed.has(i) && isDeepStrictEqual(snapshot.message, message));
        if (index >= 0) consumed.add(index);
        emitMessage(raw, message, index >= 0 ? snapshots[index].state : partialAssistant && position === lastAssistant ? assistantState : newMessageState());
      }
    } else if (raw.type === "error") emit(raw, "session.error", { error: raw.error ?? raw.message });
    else {
      const flat = normalizeAgentSession(transformFlatSessionEntries([raw]), { sourceEngine: "pi" });
      if (flat.length) events.push(...flat);
      else if (typeof raw.type === "string" && raw.type !== "") emit(raw, "session.info", { sourceType: raw.type, content: raw });
    }
  }
  return events;
}

/** @param {any} usage @returns {Record<string, any>} */
function piUsage(usage) {
  return {
    ...usage,
    input_tokens: usage.input ?? usage.input_tokens,
    output_tokens: usage.output ?? usage.output_tokens,
    cache_read_input_tokens: usage.cacheRead ?? usage.cache_read_input_tokens,
    cache_creation_input_tokens: usage.cacheWrite ?? usage.cache_creation_input_tokens,
    total_tokens: usage.totalTokens ?? usage.total_tokens,
  };
}

/**
 * Count finalized assistant messages once, even in interrupted streams that lack
 * turn_end. agent_end.messages is a transcript snapshot, never extra usage.
 * @param {Array<any>} records
 * @returns {any}
 */
function computePiV3Stats(records) {
  records = records.filter(record => record && typeof record === "object" && !Array.isArray(record));
  /** @type {Record<string, any>} */
  const usage = {};
  let turns = 0;
  let reportedTurns;
  let totalCostUsd;
  let durationMs;
  let exposedErrors = false;
  /** @type {Array<any>} */
  const errors = [];
  const seen = new Map();
  const auxiliarySeen = new Set();
  let compactionCount = 0;
  /** @type {any} */
  let lastReport;
  let lastWasMessageEnd = false;
  let lastWasMessageUpdate = false;
  const reports = [];
  const addAuxiliaryUsage = (key, value) => {
    if (!value || auxiliarySeen.has(key)) return;
    auxiliarySeen.add(key);
    const normalized = piUsage(value);
    for (const field of ["input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens", "total_tokens"]) {
      if (isTokenCount(normalized[field])) usage[field] = (usage[field] ?? 0) + normalized[field];
    }
    if (isMetric(value.cost?.total)) totalCostUsd = (totalCostUsd ?? 0) + value.cost.total;
    if (isTokenCount(value.input)) usage.input_tokens_include_cache = false;
  };
  const addMessage = (raw, message) => {
    if (!message || message.role !== "assistant") return;
    const identity = messageIdentity(message) ?? (raw.id !== undefined && raw.type !== "agent_end" ? JSON.stringify(["record", raw.id]) : undefined);
    const sourceIdentity = raw.id !== undefined && raw.type !== "agent_end" ? JSON.stringify(["record", raw.id]) : undefined;
    const signature = { ...message, usage: undefined, errorMessage: undefined };
    let report = (sourceIdentity !== undefined && seen.get(sourceIdentity)) || (identity !== undefined && seen.get(identity));
    if (!report && ((raw.type === "turn_end" && lastWasMessageEnd) || (raw.type === "message_end" && lastWasMessageUpdate)) && isDeepStrictEqual(lastReport?.signature, signature)) report = lastReport;
    if (!report) {
      report = { signature: structuredClone(signature), message: structuredClone(message), usage: {}, cost: undefined, error: undefined };
      reports.push(report);
      turns++;
    }
    if (identity !== undefined) seen.set(identity, report);
    if (sourceIdentity !== undefined) seen.set(sourceIdentity, report);
    lastReport = report;
    lastWasMessageUpdate = raw.type === "message_update";
    lastWasMessageEnd = raw.type === "message_end" || lastWasMessageUpdate;
    report.message = structuredClone(message);
    if (message.usage && typeof message.usage === "object") {
      const normalized = piUsage(message.usage);
      for (const key of ["input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens", "total_tokens"]) {
        if (!isTokenCount(normalized[key])) continue;
        usage[key] = (usage[key] ?? 0) + normalized[key] - (report.usage[key] ?? 0);
        report.usage[key] = normalized[key];
      }
      // CI totalTokens and the driver usage agree that Pi input excludes cache.
      if (isTokenCount(message.usage.input) && [message.usage.cacheRead, message.usage.cacheWrite].some(isTokenCount)) usage.input_tokens_include_cache = false;
      if (isMetric(message.usage.cost?.total)) {
        totalCostUsd = (totalCostUsd ?? 0) + message.usage.cost.total - (report.cost ?? 0);
        report.cost = message.usage.cost.total;
      }
    }
    if (message.errorMessage !== undefined && !isDeepStrictEqual(report.error, message.errorMessage)) {
      errors.push(structuredClone(message.errorMessage));
      report.error = structuredClone(message.errorMessage);
    }
  };
  for (const raw of records) {
    if (raw.type === "turn_start") {
      lastReport = undefined;
      lastWasMessageEnd = false;
      lastWasMessageUpdate = false;
    } else if (raw.type === "message_update" && ["done", "error"].includes(raw.assistantMessageEvent?.type)) {
      addMessage(raw, raw.assistantMessageEvent.message ?? raw.assistantMessageEvent.error);
    } else if (raw.type === "message_end" || raw.type === "turn_end" || (raw.type === "message" && raw.message)) {
      addMessage(raw, raw.message);
      if (raw.message?.role === "toolResult") addAuxiliaryUsage(`tool:${raw.message.toolCallId}`, raw.message.usage);
      for (const result of raw.toolResults ?? []) addAuxiliaryUsage(`tool:${result.toolCallId}`, result.usage);
    } else if (["usage", "compaction", "branch_summary"].includes(raw.type)) {
      addAuxiliaryUsage(`${raw.type}:${raw.id}`, raw.usage);
    } else if (raw.type === "compaction_end") {
      addAuxiliaryUsage(`compaction:${compactionCount++}`, raw.result?.usage);
      if (raw.errorMessage) errors.push(raw.errorMessage);
    } else if (raw.type === "entry_appended" && raw.entry?.type === "usage") {
      addAuxiliaryUsage(`usage:${raw.entry.id}`, raw.entry.usage);
    } else if (raw.type === "auto_retry_end" && raw.success === false) {
      errors.push(raw.finalError);
    } else if (raw.type === "agent_end") {
      const remaining = [...reports];
      for (const message of raw.messages ?? []) {
        const index = remaining.findIndex(report => isDeepStrictEqual(report.message, message));
        if (index >= 0) remaining.splice(index, 1);
        else addMessage(raw, message);
      }
      const snapshot = raw.usage ?? raw.stats?.usage ?? raw.stats;
      if (snapshot && typeof snapshot === "object") {
        const normalized = piUsage(snapshot);
        for (const key of ["input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens", "total_tokens"]) {
          if (isTokenCount(normalized[key])) usage[key] = normalized[key];
        }
        if (isTokenCount(snapshot.input) && [snapshot.cacheRead, snapshot.cacheWrite].some(isTokenCount)) usage.input_tokens_include_cache = false;
      }
      const cost = raw.total_cost_usd ?? raw.totalCostUsd ?? raw.stats?.total_cost_usd ?? snapshot?.cost?.total;
      if (isMetric(cost)) totalCostUsd = cost;
      const duration = raw.durationMs ?? raw.duration_ms ?? raw.stats?.duration_ms;
      if (isMetric(duration)) durationMs = duration;
      const count = raw.numTurns ?? raw.num_turns ?? raw.stats?.turns;
      if (isTokenCount(count)) reportedTurns = count;
      const diagnostics = raw.errors ?? raw.stats?.errors;
      if (Array.isArray(diagnostics)) {
        exposedErrors = true;
        errors.push(...structuredClone(diagnostics));
      }
    } else if (raw.type === "result" || raw.type === "session.result") {
      const result = normalizeAgentSession(transformFlatSessionEntries([raw]), { sourceEngine: "pi" }).find(event => event.type === "session.result")?.data;
      if (!result) continue;
      if (result.usage) {
        for (const [key, value] of Object.entries(result.usage)) {
          if (isTokenCount(value) || key === "input_tokens_include_cache") usage[key] = value;
        }
      }
      if (isMetric(result.totalCostUsd)) totalCostUsd = result.totalCostUsd;
      if (isMetric(result.durationMs)) durationMs = result.durationMs;
      if (isTokenCount(result.numTurns)) reportedTurns = result.numTurns;
    } else if (raw.type === "error") {
      const error = raw.error ?? raw.message;
      if (error !== undefined) errors.push(structuredClone(error));
    }
  }
  if (turns === 0 && reportedTurns === undefined && Object.keys(usage).length === 0 && errors.length === 0 && !exposedErrors && totalCostUsd === undefined && durationMs === undefined) return null;
  return {
    turns: reportedTurns ?? (turns || undefined),
    input_tokens: usage.input_tokens,
    output_tokens: usage.output_tokens,
    usage: Object.keys(usage).length ? usage : undefined,
    total_cost_usd: totalCostUsd,
    duration_ms: durationMs,
    errors,
    exposedErrors,
  };
}

module.exports = { transformPiV3Entries, computePiV3Stats, normalizePiObservations };
